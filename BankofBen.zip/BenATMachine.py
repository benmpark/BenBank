# CSC6003 FINAL PROJECT
# Automatic Teller Machine File
# @author Benjamin Park
# March 6, 2023

from BenBankUtility import *

class ATMachine:
    @staticmethod
    def atm_withdrawal(withdraw, account=None):
        """
        Withdraws cash in $20s, $10s, and $5s from an account.

        The ATM will return as many $20 bills as possible

        Arguments
        ---------
        withdraw : int
            The amount to be withdrawn (must be a multiple of 5)
        
        account : Account, optional
            The account object from which the money will be withdrawn

        Parameters
        ---------
        MAX_WITHDRAWAL : int
            The maximum amount, in dollars that can be withdrawn at once
        
        Returns
        -------
        twenties : int
            The number of $20 bills to be dispensed
        tens : int
            The number of $10 bills to be dispensed
            (Always 0 or 1)
        fives : int
            The number of $5 bills to be dispensed
            (Always 0 or 1)

        Raises
        ------
        ValueError
            The withdrawal amount is negative or not divisible by 5
        Exception
            The account does not have sufficient funds
        """
        
        MAX_WITHDRAWAL = 1000

        # Skip the whole process in case somehow the user enters a
        #   withdrawal amount of exactly 0
        if withdraw == 0:
            print("\nDid you really come to the ATM to withdraw nothing?")
            return 0, 0, 0

        # Shut down the ATM withdrawal if there are problems (most of
        #   which are handled by the main program itself
        #   (1) Withdrawal amount is negative
        if withdraw < 0:
            raise ValueError("Error: invalid withdrawal amount")
        
        #   (2) Withdrawal amount is not divisible by 5
        elif withdraw % 5 != 0:
            raise ValueError("Error: invalid withdrawal amount")
        
        #   (3) Withdrawal amount is above the set limit
        elif withdraw > MAX_WITHDRAWAL:
            raise ValueError("Error: withdrawal amount too high")

        #   (4) The account, if specified, does not have sufficient funds
        elif (account 
                and BankUtility.convert_dollars_to_cents(withdraw)
                > account.get_balance()):
            raise Exception("Error: insufficient funds")

        # Assuming the withdrawal amount is OK and an account was
        #   specified, withdraw the amount and set the new balance
        if account != None:
            account.set_balance(account.withdraw(withdraw))

        # Then figure out how many of each bill to dispense
        bills = [["$20", 0], ["$10", 0], ["$ 5", 0]]
        bills[0][1] = twenties = withdraw // 20
        bills[1][1] = tens = 1 if withdraw % 20 >= 10 else 0
        bills[2][1] = fives = 0 if withdraw % 10 == 0 else 1
        
        # Print the results to the screen
        print("\nNow dispensing...")
        for kind in bills:
            if kind[1] == 1:
                print(f"{kind[1]:2.0f} {kind[0]} bill")
            elif kind[1] > 1:
                print(f"{kind[1]:2.0f} {kind[0]} bills")
        
        # Display confirmation
        #   Convert to dollars b/c with method takes dollars
        #   (Only executes if an account was specified as a parameter)
        if account != None:
            print(f"\n${withdraw:,.2f} withdrawn from account "
                + f"{account.acctnum}.")
            print(f"New account balance: "
                + BankUtility.display_dollars(account.get_balance()))
        
            return twenties, tens, fives, account.get_balance()
        
        # If no account specified, just return the bill information
        return twenties, tens, fives