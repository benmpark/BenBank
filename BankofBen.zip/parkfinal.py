# CSC6003 FINAL PROJECT
# Main Program File
# @author Benjamin Park
# March 6, 2023

# This file's purpose is to have everything ultimately in one place.
# With the important statement below, it effectively imports all the different

from BenBankManager import *

# Run the program
if __name__ == '__main__':
    BankManager.main()