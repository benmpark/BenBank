# CSC6003 FINAL PROJECT
# Coin Collector File
# @author Benjamin Park
# March 6, 2023

from BenBankUtility import *

class CoinCollector:
    @staticmethod
    def parse_change(coins, account=None):
        """
        Takes a string of coins and makes cents of it. :-)

        Parameters
        ----------
        coins : str
            The string representing a collection of coins
        account : Account, optional
            The account into which the change should be deposited once
            the change has been parsed

        Returns
        -------
        total_coins : int
            The total number of coins parsed (the length of the string)
        total_change : int
            The value, in cents, represented by the coins
        bad_coins : int
            The number of unrecognized coins (not P, N, D, Q, H, or W)
        bad_coins_list : str
            A string containing all the rejected coins
            (i.e., any unrecognized characters)
        int, optional
            The new balance of the account if an account was included as
            a parameter when the function was called
        """

        total_change = 0
        total_coins = 0
        bad_coins = 0
        bad_coins_list = ""

        # Make uppercase any characters typed in lowercase by user
        coins = coins.replace(" ", "").upper()

        # Examine each coin; add corresponding value to tally or add
        #   coin to rejected 'pile'
        for char in coins:
            total_coins += 1
            if char == "P":
                total_change += 1
            elif char == "N":
                total_change += 5
            elif char == "D":
                total_change += 10
            elif char == "Q":
                total_change += 25
            elif char == "H":
                total_change += 50
            elif char == "W":
                total_change += 100
            else:
                bad_coins_list += char
                bad_coins +=1
        
        # Display the results to the user.
        print(f"\n{total_coins} coins processed.")
        if bad_coins > 0:
            print(f"{bad_coins} coins not accepted:", bad_coins_list)
        else:
            print("All coins accepted.")
        
        # Add change to account balance and display confirmation
        #   Convert to dollars b/c deposit method takes dollars
        #   (Only executes if an account was specified as a parameter)
        if account:
            account.deposit(BankUtility.convert_cents_to_dollars(total_change))
            print(f"{BankUtility.display_dollars(total_change)} in coins deposited"
                + f" into account {account.get_account_number()}.")
            print(f"New account balance: "
                + BankUtility.display_dollars(account.get_balance()))

            return(
                total_coins,
                total_change,
                bad_coins,
                bad_coins_list,
                account.get_balance(),
            )
        
        # If no account specified, just return the coin information
        
        return(
            total_coins,
            total_change,
            bad_coins,
            bad_coins_list,
        )