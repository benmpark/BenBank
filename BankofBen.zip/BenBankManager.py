# CSC6003 FINAL PROJECT
# Bank Manager File
# @author Benjamin Park
# March 6, 2023

import textwrap
import os

from BenBank import *
from BenAccount import *
from BenBankUtility import *
from BenCoinCollector import *
from BenATMachine import *

class BankManager:
    # def __init__(self):
    #     pass

    @staticmethod    
    def prompt_for_account_number_and_pin(bank):
        """
        Prompts the user for an account number an PIN.

        Arguments
        ---------
        bank : Bank
            The Bank object where the user is being prompted
        
        Returns
        -------
        Account
            The account object with the specified number and PIN (if
            entered correctly by the user); otherwise None
            (None is also returned if the provided account number
            does not match any account on record.)
        """
        
        acct = BankUtility.prompt_user_for_non_neg_int(
            "Enter account number:\n",
            False,
        )
        if bank.find_account(acct) == None:
            print(f"Account not found for account number {acct}.")
            return None   
        while True:
            mypin = BankUtility.prompt_user_for_string(
                "Enter PIN:\n"
            )
            if bank.find_account(acct).is_valid_pin(mypin):
                return bank.find_account(acct)
            else:
                print("Invalid PIN")
                return None
    
    @staticmethod
    def userLogin(bank):
        """
        Logs the user into the account-related transaction with valid info.

        Arguments
        ---------
        bank : Bank
            The Bank object where the user is trying to log in
        
        Returns
        -------
        login : Account
            An account object once the correct account number and PIN
            have been provided by the user
        """

        login = None
        while login == None:
            login = BankManager.prompt_for_account_number_and_pin(
                bank
            )
        return login
            
    def screen_clear():
        """A simple method for clearing the terminal screen."""

        if os.name == "posix":
            os.system("clear")
        else:
            os.system("cls")
    
    @staticmethod
    def open_account(bank):
        """
        Runs the code that will open a new account.

        Arguments
        ---------
        bank : Bank
            The bank object where the account should be opened
        """
        
        # Generate available account number
        newnum = 0
        
        while True:
            newnum = BankUtility.generate_account_number(8)
            if bank.is_account_number_available(newnum):
                break

        newaccount = Account(newnum)

        if bank.add_account_to_bank(newaccount):
            
            # Populate account characteristics
            #   (Account number set automatically)
            #   (Balance initilized to $0.00 automatically)
            newaccount.set_owner_first_name(
                BankUtility.prompt_user_for_string(
                    "Enter account owner's first name:\n"
                )
            )
            newaccount.set_owner_last_name(
                BankUtility.prompt_user_for_string(
                    "Enter account owner's last name:\n"
                )
            )
            while True:
                ssn = BankUtility.prompt_user_for_string(
                    "Enter account owner's Social Security Number "
                    + "(9 digits):\n"
                ).replace("-", "").strip(" ")
                if BankUtility.is_numeric(ssn) and len(ssn) == 9:
                    newaccount.set_owner_ssn(ssn)
                    break
                else:
                    print("Error: Social Security Number must be 9 "
                        + "digits.")

            # Print the account information
            print(newaccount)
        
        else:
            print("Error: there are no new accounts available.")

    @staticmethod
    def change_pin(bank):
        """
        Runs the code that will allow a user to change PINs.

        Arguments
        ---------
        bank : Bank
            The bank object where the PINs will be changed
        """
        
        if bank.check_if_accounts():
            account = BankManager.userLogin(bank)

            newpin = ""

            while True:
                newpin = BankUtility.prompt_user_for_string(
                    "Enter a new 4-digit PIN:\n"
                ).strip(" ")
                if (len(newpin) != 4 or 
                        not BankUtility.is_numeric(newpin)):
                    print("Error: PIN must be 4 digits, try again.")
                    continue
                else:
                    confirm = BankUtility.prompt_user_for_string(
                        "Enter new PIN again to confirm:\n"
                    )
                    if newpin == confirm:
                        break
                    else:
                        print("Error: PINs do not match; try again.")
            
            account.set_pin(newpin)
            print(f"PIN for account {account.acctnum} updated.")
                
        else:
            print("Error: there are no accounts currently open.")

    @staticmethod
    def make_deposit(bank):
        """
        Runs the code that will make a deposit.

        Arguments
        ---------
        bank : Bank
            The bank object where the deposit will be made.
        """

        if bank.check_if_accounts():
            account = BankManager.userLogin(bank)

            deposit = BankUtility.prompt_user_for_non_neg_float(
                "Enter amount to deposit, in dollars and cents:\n$"
            )

            account.set_balance(account.deposit(deposit))
            print(f"\n${deposit:,.2f} deposited into account "
                + f"{account.acctnum}.")
            print(f"New account balance: "
                + BankUtility.display_dollars(account.get_balance()))
            
        else:
            print("Error: there are no accounts currently open.")

    @staticmethod
    def transfer_funds(bank):
        """
        Runs the code that will transfer funds between two accounts.

        Arguments
        ---------
        bank : Bank
            The bank object where the transfer will happen.
        """
        
        if bank.account_tally >= 2:

            while True:

                print("FROM which account would you like to transfer funds?")
                fromaccount = BankManager.userLogin(bank)

                print("TO which account would you like to move the funds?")
                toaccount = BankManager.userLogin(bank)

                if fromaccount != toaccount:
                    break
                else:
                    print("Error: account numbers must be different,")

            transfer = BankUtility.prompt_user_for_non_neg_float(
                    "Enter amount to transfer in dollars and cents:\n$"
            )

            try:
                fromaccount.withdraw(transfer)
                toaccount.deposit(transfer)
                print("\nTransfer complete.\n")
                print(f"New balance in account {fromaccount.acctnum}: "
                    + BankUtility.display_dollars(
                        fromaccount.get_balance()
                    )
                )
                print(f"New balance in account {toaccount.acctnum}: "
                    + BankUtility.display_dollars(
                        toaccount.get_balance()
                    )
                )
            except Exception as e:
                print(e, f"in account {fromaccount.acctnum}.")
        
        elif bank.account_tally == 1:
            print("Error: there must be at least two open accounts in the bank"
                + " to make a transfer.\nThere is only one account open.")
        else:
            print("Error: there must be at least two open accounts in the bank"
                + " to make a transfer.\nThere are no accounts open currently.")
    
    @staticmethod
    def make_withdrawal(bank):
        """
        Runs the code that will withdraw money.

        Arguments
        ---------
        bank : Bank
            The bank object where the withdrawal will happen.
        """

        if bank.check_if_accounts():
            account = BankManager.userLogin(bank)

            withdraw = BankUtility.prompt_user_for_non_neg_float(
                "Enter amount to withdraw, in dollars and cents:\n$"
            )

            try:
                account.set_balance(account.withdraw(withdraw))
                print(f"\n${withdraw:,.2f} withdrawn from account "
                    + f"{account.acctnum}.")
                print(f"New account balance: "
                    + BankUtility.display_dollars(
                        account.get_balance()
                    )
                )
            except Exception as e:
                print(e, f"in account {account.acctnum}.")

        else:
            print("Error: there are no accounts currently open.")

    @staticmethod
    def atm(bank):
        """
        Runs the code to make an ATM withdrawal.

        Arguments
        ---------
        bank : Bank
            The bank object where the ATM is 'located.'
        """
        
        if bank.check_if_accounts():
            account = BankManager.userLogin(bank)

            withdraw = 0
            while True:
                withdraw = BankUtility.prompt_user_for_non_neg_int(
                    "\nEnter the amount you wish to withdraw in whole "
                    + "dollars (no cents) in\nmultiples of $5 (max $1000):"
                    + "\n$",
                    True
                )

                if withdraw % 5 != 0:
                    print("Error: ATM withdrawal amount must be in "
                        + "multiples of $5.")
                    continue
                elif withdraw > 1000:
                    print("Error: Maximum ATM withdrawal amount is $1000.")
                    continue
                else:
                    break
            
            try:
                ATMachine.atm_withdrawal(withdraw, account)
            except ValueError as v:
                print(v)
            except Exception as e:
                print(e, f"in account {account.acctnum}.")
        
        else:
            print("Error: there are no accounts currently open.")

    @staticmethod
    def deposit_change(bank):
        """
        Runs the code to parse and deposit change into an account.

        Arguments
        ---------
        bank : Bank
            The bank object where the coins are being parsed and deposited.
        """
        
        if bank.check_if_accounts():
            account = BankManager.userLogin(bank)

            change = BankUtility.prompt_user_for_string(
                "Please deposit your coins below:\n"
            )
            
            CoinCollector.parse_change(change, account)
        
        else:
            print("Error: there are no accounts currently open.")
    
    @staticmethod
    def close_account(bank):
        """
        Runs the code to close an account.

        Arguments
        ---------
        bank : Bank
            The bank object where the account is being closed.
        """

        if bank.check_if_accounts():
            account = BankManager.userLogin(bank)

            temp_balance = account.get_balance()
    
            bank.remove_account_from_bank(account)

            print(f"\nAccount {account.acctnum} has been closed.")
            print("\nWe are sorry to see you leave, "
                + account.get_owner_first_name() + " "
                + account.get_owner_last_name() + ".\n\n"
                + f"The {BankUtility.display_dollars(account.get_balance())} "
                + "that was left in your account immediately prior\nto closing"
                + " has been mailed to your address on file.\n\nIf you have "
                + "any feedback for our customer service department,\nplease "
                + "call 1-800-BEN-BANK.")
        
        else:
            print("Error: there are no accounts currently open.")
        
    
    @staticmethod
    def monthly_interest(bank):
        """
        Runs the code that will add monthly interest to all accounts.

        Arguments
        ---------
        bank : Bank
            The bank object where the monthly interest will be added.
        """

        if bank.check_if_accounts():
            apr = BankUtility.prompt_user_for_non_neg_float(
                "Enter the annual percentage rate as a percentage: "
            )
            try:
                bank.add_monthly_interest(apr)
                print("\nMonthly interest applied to all accounts.")
            except ValueError as v:
                print(v)
            except TypeError as t:
                print(t)
        
        else:
            print("You might be INTERESTED to know that there are no "
                + "accounts currently open.")

    
    # Bank logo
    logo = """
        8 888888888o          .8.          b.             8 8 8888     ,88'
        8 8888    `88.       .888.         888o.          8 8 8888    ,88'
        8 8888     `88      :88888.        Y88888o.       8 8 8888   ,88'
        8 8888     ,88     . `88888.       .`Y888888o.    8 8 8888  ,88'
        8 8888.   ,88'    .8. `88888.      8o. `Y888888o. 8 8 8888 ,88'
        8 8888888888     .8`8. `88888.     8`Y8o. `Y88888o8 8 8888 88'
        8 8888    `88.  .8' `8. `88888.    8   `Y8o. `Y8888 8 888888<
        8 8888      88 .8'   `8. `88888.   8      `Y8o. `Y8 8 8888 `Y8.
        8 8888    ,88'.888888888. `88888.  8         `Y8o.` 8 8888   `Y8.
        8 888888888P .8'       `8. `88888. 8            `Yo 8 8888     `Y8.


                                           $$$$$$\\
                                          $$  __$$\\
                                 $$$$$$\\  $$ /  \\__|
                                $$  __$$\\ $$$$\\
                                $$ /  $$ |$$  _|
                                $$ |  $$ |$$ |
                                \\$$$$$$  |$$ |
                                 \\______/ \\__|

                            
                8 888888888o   8 8888888888   b.             8
                8 8888    `88. 8 8888         888o.          8
                8 8888     `88 8 8888         Y88888o.       8
                8 8888     ,88 8 8888         .`Y888888o.    8
                8 8888.   ,88' 8 888888888888 8o. `Y888888o. 8
                8 8888888888   8 8888         8`Y8o. `Y88888o8
                8 8888    `88. 8 8888         8   `Y8o. `Y8888
                8 8888      88 8 8888         8      `Y8o. `Y8
                8 8888    ,88' 8 8888         8         `Y8o.`
                8 888888888P   8 888888888888 8            `Yo
    """

    # Main Menu Options
    options = [" Open an account", " Get account information and balance",
                " Change PIN", " Deposit money in account",
                " Transfer money between accounts",
                " Withdraw money from account", " ATM withdrawal",
                " Deposit change", " Close an account",
                "Add monthly interest to all accounts", "End program"]
    options_divider = "=" * 60
    
    def main():
        """The main method in the Bank of Ben Program"""
        
        # Display bank logo
        BankManager.screen_clear()
        print(textwrap.dedent(BankManager.logo))
        input("\n\n" + " "*20 + "Press ENTER to continue...")
        
        # Create an instance of Bank object
        bank_of_Ben = Bank()

        BankManager.screen_clear()
        # Print the main menu
        while True:
            print("\n" + BankManager.options_divider)
            print("\nHow can we help you today?\n")
            for i in range(11):
                print(f"{i+1}. {BankManager.options[i]}\n")
            print(BankManager.options_divider)
            selection = BankUtility.prompt_user_for_string(
                "\nEnter your selection and hit ENTER: "
            ).strip(" .").lstrip("0")

            ###################################################################
            ################### MENU OPTIONS IMPLEMENTATION ###################
            ###################################################################

            if selection == "1":
                print("\nOPEN ACCOUNT\n")
                BankManager.open_account(bank_of_Ben)

            ###################################################################

            elif selection == "2":
                print("\nGET ACCOUNT INFORMATION AND BALANCE\n")
                
                if bank_of_Ben.check_if_accounts():
                    print(BankManager.userLogin(bank_of_Ben))
                else:
                    print("Error: there are no accounts currently open.")

            ###################################################################

            elif selection == "3":
                print("\nCHANGE PIN\n")
                BankManager.change_pin(bank_of_Ben)

            ###################################################################

            elif selection == "4":
                print("\nMAKE A DEPOSIT\n")
                BankManager.make_deposit(bank_of_Ben)
                
            ###################################################################

            elif selection == "5":
                print("\nTRANSFER FUNDS\n")
                BankManager.transfer_funds(bank_of_Ben)

            ###################################################################

            elif selection == "6":
                print("\nWITHDRAW MONEY\n")
                BankManager.make_withdrawal(bank_of_Ben)

            ###################################################################

            elif selection == "7":
                print("\nATM WITHDRAWAL\n")
                BankManager.atm(bank_of_Ben)

            ###################################################################

            elif selection == '8':
                print("\nDEPOSIT CHANGE\n")
                BankManager.deposit_change(bank_of_Ben)
                
            ###################################################################

            elif selection == "9":
                print("\nCLOSE AN ACCOUNT\n")
                BankManager.close_account(bank_of_Ben)
                
            ###################################################################

            elif selection == "10":
                print("\nADD MONTHLY INTEREST TO ALL ACCOUNTS\n")
                BankManager.monthly_interest(bank_of_Ben)

            ###################################################################

            elif selection == "11":
                break

            ###################################################################

            else:
                print("Error: invalid choice. Please try again.")

            ###################################################################
            ############### END OF MENU OPTIONS IMPLEMENTATION ################
            ###################################################################
        
        # Parting remarks
        print("\nIt has been our pleasure to serve you. Have a nice day!\n")