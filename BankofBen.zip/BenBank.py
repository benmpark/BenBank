# CSC6003 FINAL PROJECT
# Bank Program File
# @author Benjamin Park
# March 6, 2023

from BenBankUtility import *

class Bank:
    """
    Class representing an entire bank account.

    Parameters
    ----------
    max_accounts : int, optional
        The maximum number of accounts the bank can hold; defaults to 100
    """

    def __init__(self, max_accounts=100):
        self.max_accounts = max_accounts
        self.accounts = [None] * max_accounts   # Array of accounts
        self.acctnums = []                      # List of account numbers
        self.account_tally = 0                  # Counter
    
    
    def check_if_accounts(self):
        """
        Checks to see if there is at least one account in a bank.

        Intended to prevent getting stuck in the user login prompt if
        certain menu options are chosen before an account is opened.

        Arguments
        ---------
        bank : Bank
            The bank in which the function checks for accounts

        Returns
        -------
        bool
            True if the bank has at least one account, otherwise False
        """

        for i in range(self.max_accounts):
            if self.accounts[i] != None:
                return True
        else:
            return False
    
    def is_account_number_available(self, account_number):
        """
        Checks if an account number is available (not duplicated).

        Parameters
        ----------
        account_number : int
            The new account number to be checked

        Returns
        -------
        bool
            True if account number is available, otherwise False
        """
        
        return True if account_number not in self.acctnums else False
    
    def add_account_to_bank(self, account):
        """
        Adds an account to the bank.

        The account number is also added to the list of account numbers,
        and the account tally is incremented by 1.

        Parameters
        ----------
        account : Account
            The account (object) to be added

        Returns
        -------
        bool
            True if account is added successfully, otherwise False
        """

        if self.account_tally < self.max_accounts:
            for i in range(self.max_accounts):
                if self.accounts[i] == None:
                    self.accounts[i] = account
                    self.acctnums.append(account.acctnum)
                    self.account_tally += 1
                    return True
        else:
            print("Error: no more accounts available.")
            return False

    def remove_account_from_bank(self, account):
        """
        Removes an account from the bank.

        The account number is also removed from the list of account numbers,
        and the account tally is decreased by 1.

        Parameters
        ----------
        account : Account
            The account (object) to be removed

        Returns
        -------
        bool
            True if account is removed successfully, otherwise False
        """

        for i in range(self.max_accounts):
            if self.accounts[i] == account:
                self.accounts[i] = None
                self.acctnums.remove(account.acctnum)
                self.account_tally -= 1
                return True
        else:
            return False

    def find_account(self, account_number):
        """
        Finds an account given an account number.

        Arguments
        ---------
        account_number : int
            The number of the account being looked up
        
        Returns
        -------
        Account
            Returns the Account object once found, otherwise returns None
        """
        
        for i in range(self.max_accounts):
            if (self.accounts[i] != None
                    and self.accounts[i].acctnum == account_number):
                return self.accounts[i]
        else:
            return None
    
    def add_monthly_interest(self, percent):
        """
        Adds monthly interest to all accounts in a bank.

        Divides the given APR by 12 to calculate the monthly interest
        rate, then applies that interest rate to all accounts in the
        bank.

        Arguments
        ---------
        percent : float
            The annual percentage rate, as a percent (e.g., 2.25)
        
        Raises
        ------
        ValueError
            If the percentage rate entered is negative
        TypeError
            If the percentage rate entered is not numerical
        
        """
        
        try:
            fpercent = float(percent)
        except:
            # This error should not come up when the program is actually
            #   run because the user is being prompted for a non-negative
            #   float first, and that method checks that input.
            raise TypeError("Error annual percentage rate must be numerical.")
        
        if fpercent < 0:
            # This error should also never be raised in the main program
            raise ValueError("Error: annual percentage rate cannot be "
                                + "negative.")
            
        monthly_rate = fpercent / 100 / 12
        for i in range(self.max_accounts):
            if self.accounts[i] != None:
                interest = round(
                    self.accounts[i].get_balance()
                    * monthly_rate)
                self.accounts[i].set_balance(
                    self.accounts[i].get_balance()
                    + interest
                )
                new_balance = self.accounts[i].get_balance()
                print(f"\nDeposited {BankUtility.display_dollars(interest)} in"
                    + f" interest to account "
                    + f"{self.accounts[i].get_account_number()}.\nNew account"
                    + " balance is "
                    + f"{BankUtility.display_dollars(new_balance)}.")

                