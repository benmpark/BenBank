# CSC6003 FINAL PROJECT
# Bank Utility File
# @author Benjamin Park
# March 6, 2023

import random
import math

class BankUtility:
    @staticmethod
    def prompt_user_for_string(prompt):
        """
        Prompts the user for a string.

        Arguments
        ---------
        prompt : str
            The prompt to be displayed to the user

        Returns
        -------
        str
            The user's input in string form
        """

        return input(prompt).strip(" ")

    @staticmethod
    def prompt_user_for_non_neg_float(prompt):
        """
        Prompts the user for a nonnegative number (can be a non-integer).

        Designed for prompting amounts to deposit, withdraw, transfer, etc., so
        the method can take anything greater than or equal to zero.

        Arguments
        ---------
        prompt : str
            The prompt to be displayed to the user

        Returns
        -------
        float
            The float version of the user's input
        """

        while True:
            try:
                entry = BankUtility.strip_currency(input(prompt))
                fentry = float(entry)
                if fentry >= 0:
                    return fentry
                else:
                    print("Error: please enter a value greater than or equal "
                        + "to zero.")
            except ValueError:
                print(f"Error: please input nonnegative numerical values "
                    + "only.")
    
    @staticmethod
    def prompt_user_for_non_neg_int(prompt, is_currency):
        """
        Prompts the user for a nonnegative integer.

        Arguments
        ---------
        prompt : str
            The prompt to be displayed to the user
        isCurrency : bool
            If set to True, will strip '$' and commas from the user's input.
            If set to False, will only accept (nonnegative) numerical inputs.

        Returns
        -------
        int
            The integer version of the user's input
        """

        while True:
                entry = input(prompt).strip(" ")
                if is_currency:
                    entry = entry.lstrip("$").replace(",", "")
                if not BankUtility.is_numeric(entry):
                    print("Please input digits only.")
                else:
                    return int(entry)

    @staticmethod
    def generate_random_integer(min, max):
        """
        Generates and random integer.

        Arguments
        ---------
        min : int
            The minimum possible integer that can be returned
        max : int
            The maximum possible integer that can be returned

        Returns
        -------
        int
            The randomly generated integer
        """

        return random.randint(min, max)
    
    @staticmethod
    def generate_account_number(number_of_digits):
        """
        Generates a new account number (that cannot start with a zero)

        Parameters
        ----------
        number_of_digits : int
            The number of digits in the account number

        Returns
        -------
        int
            A new account number with the specified number of digits
        """
        
        return BankUtility.generate_random_integer(
            10 ** (number_of_digits - 1),
            10 ** (number_of_digits) - 1
        )
    
    @staticmethod
    def generate_pin(number_of_digits):
        """
        Generates a random string with the number of digits specified.

        Uses generate_random_integer to create a random integer of the
        length specified. Leading zeros are added.

        Returns
        -------
        str
            The pin with the specified number of digits.
        """

        # Generate a random number with, at most, the number of digits
        #   passed in as an argument
        num = random.randint(0, (10 ** number_of_digits) - 1)
        # Append left the necessary number of zeros to make the string the
        #   correct length
        if num == 0:
            pin = "0" * number_of_digits
        else:
            leading_zeros = "0" * (
                (number_of_digits - 1)
                - math.floor(math.log10(num))
                )
            pin = leading_zeros + str(num)

        return pin
    
    @staticmethod
    def convert_dollars_to_cents(amount):            
        """
        Takes an amount in dollars and converts to cents.

        Arguments
        ---------
        amount : float
            Currency in dollars
        
        Returns
        -------
        float
            The input multiplied by 100.

        Raises
        ------
        TypeError
            If the amount to be converted is not a currency (e.g., a string)
        """
        
        if type(amount) != int and type(amount) != float:
            raise TypeError("Error: non-currency entry")
        
        return amount * 100
    
    @staticmethod
    def convert_cents_to_dollars(amount): 
        """
        Takes an amount in cents and converts to dollars.

        Arguments
        ---------
        amount : int or float
            Currency in cents
        
        Returns
        -------
        float
            The input divided by 100.

        Raises
        ------
        TypeError
            If the amount to be converted is not a currency (e.g., a string)
        """

        if type(amount) != int and type(amount) != float:
            raise TypeError("Error: non-currency entry")

        return amount / 100
    
    @staticmethod
    def display_dollars(cents):
        """
        Takes an account balance (in cents) and returns a string expressed
        as a dollar amount.

        Arguments
        ---------
        cents : int
            Account balance in cents
        
        Returns
        -------
        str
            A string representing the account balance in dollars.
        
        Raises
        ------
        TypeError
            If the amount to be displayed is not initially a currency
            (e.g., a string)
        """

        if type(cents) != int and type(cents) != float:
            raise TypeError("Error: non-currency entry")

        return f"${cents/100:,.2f}"
    
    @staticmethod
    def strip_currency(cs):
        """
        Takes a string and strips expected currency-related characters,
        e.g., dollar signs and separator commas.

        Arguments
        ---------
        cs : str
            A string intended to be a currency (dollar amount)
        
        Returns
        -------
        str
            The currency string without any leading dollar sign(s),
            separator commas, or extra space.
        """

        return cs.strip(" ").lstrip("$").replace(",", "").replace(" ", "")
    
    @staticmethod
    def is_numeric(string_to_check):
        """
        Determines whether a string is comprised only of digits.

        Arguments
        ---------
        string_to_check : str
            The string to be checked
        
        Returns
        -------
        bool
            True if the string is comprised only of digits (0-9)
            False if otherwise
        """

        try:
            if string_to_check.isdigit():
                return True
            else:
                return False
        except ValueError:
            return False