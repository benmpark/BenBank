# CSC6003 FINAL PROJECT
# Unit Testing File
# @author Benjamin Park
# March 6, 2023

import unittest
from parkfinal import *

TEST_BANK_MAX_ACCOUNTS = 10
test_bank = Bank(TEST_BANK_MAX_ACCOUNTS)

def set_up_bank_for_testing(bank):
    """
    Populates a preexisting Bank object it with 4 sample accounts.

    Parameters
    ----------
    bank: Bank
        The bank into which the sample accounts should be added
    """

    bank.accounts[0] = Account(
        23456789,
        "Joseph",
        "Schmozy",
        "618010242",
        "5678",
        198703
    )

    bank.accounts[1] = Account(
        12345678,
        "C. Montgomery",
        "Burns",
        "000000002",
        "1234",
        16800000000,
    )

    bank.accounts[2] = Account(
        60152005,
        "Bruce",
        "Wayne",
        "050261234",
        "9009",
        6800000000,
    )

    bank.accounts[3] = Account(
        90271924,
        "Oliver",
        "Warbucks",
        "050010001",
        "1894",
        36200000000,
    )

    bank.account_tally += 4
    bank.acctnums = [
        23456789,
        12345678,
        60152005,
        90271924,
    ]


def empty_test_bank(bank):
    """
    Removes any existing accounts in a bank.

    Arguments
    ---------
    bank : a Bank object
    """

    bank.accounts = [None] * TEST_BANK_MAX_ACCOUNTS 
    bank.account_tally = 0
    bank.acctnums = []


class TestBank(unittest.TestCase):
    """
    Tests the following Account class methods:
        add_account_to_bank
        remove_account_from_bank
        find_account
        add_monthly_interest 
    """
    
    def setUp(self):
        """Sets up the bank with sample accounts."""
        set_up_bank_for_testing(test_bank)
    
    def tearDown(self):
        """Clears the sample accounts from the bank."""
        empty_test_bank(test_bank)

    def test_add_account_to_bank_success(self):
        """
        Tests that an account is successfully added to a bank object.
        """

        # Create the new account to be added
        new_test_account = Account(
            10032021,
            "Jacob",
            "Levenfeld",
            "018071118",
            "0810"
        )
        # Add the account
        self.assertTrue(test_bank.add_account_to_bank(new_test_account))
        
    def test_add_account_to_bank_tallies(self):
        """
        Tests the updated number of accounts and account number list.
        """

        new_test_account = Account(
            10032021,
            "Jacob",
            "Levenfeld",
            "018071118",
            "0810"
        )

        test_bank.add_account_to_bank(new_test_account)

        # The test bank was set up with four accounts;
        #   there should now be five.
        self.assertEqual(test_bank.account_tally, 5)
        # The new account should have been placed in the first available slot
        self.assertEqual(test_bank.accounts[4], new_test_account)
        # Its account number should be in the updated list of account numbers
        self.assertTrue(10032021 in test_bank.acctnums)

    def test_add_account_to_bank_fail(self):
        """
        Tests that an account is not added when the bank is full.
        """
        # The test bank can hold up to 10 accounts.  If we add six more and
        #   try to add an 11th, the boolean False should be returned.
        for i in range(6):
            # We won't worry about names and SSNs, just add five new accounts
            #   with same-digit account numbers
            test_bank.add_account_to_bank(Account((1+i)*11111111))
        self.assertFalse(test_bank.add_account_to_bank(Account(77777777)))

    def test_is_account_number_available(self):
        """
        Tests that an account number won't be chosen if already in use.
        """

        # We'll try out a few of the known account numbers in our test bank
        self.assertFalse(test_bank.is_account_number_available(23456789))
        self.assertFalse(test_bank.is_account_number_available(12345678))
    
    def test_add_account_to_bank_acctnums(self):
        """
        Tests that account numbers don't get duplicated.
        """

        # We'll create a new test bank that can hold 90 accounts
        #   (Each account number will be 2 digits)
        test_bank_2 = Bank(90)

        # Now we'll try to add a new account 90 times.
        # Since there are 90 (2-digit) account numbers available,
        #   we should generate all of them exactly once
        while test_bank_2.account_tally < 90:
            new_act_num = BankUtility.generate_account_number(2)
            if test_bank_2.is_account_number_available(new_act_num):
                test_bank_2.add_account_to_bank(Account(new_act_num))
        
        # Copy each account number from the bank's account number list
        #   to a set.  The length of the set should be 90; if there are
        #   duplicate account numbers, the duplicates would not be added
        #   to the set.
        account_number_set = set()
        for number in test_bank_2.acctnums:
            account_number_set.add(number)
        self.assertEqual(len(account_number_set), 90)
    
    def test_remove_account_from_bank_success(self):
        """
        Tests that an account is successfully removed from a bank object.
        """

        # Remove one of the accounts from the test bank
        self.assertTrue(
            test_bank.remove_account_from_bank(
                test_bank.accounts[2]
            )
        )

    def test_remove_account_from_bank_tallies(self):
        """
        Tests scenarios when an account should not successfully be removed.
        """

        # Remove one of the accounts from the test bank
        test_bank.remove_account_from_bank(test_bank.accounts[2])

        # The test bank was set up with four accounts;
        #   there should now be three.
        self.assertEqual(test_bank.account_tally, 3)
        # The account number of the removed account should not be in the
        #   list of account numbers
        self.assertFalse(60152005 in test_bank.acctnums)
        
    
    def test_remove_account_from_bank_fail(self):
        """
        Tests scenarios when an account should not successfully be removed.
        """

        # The account is not in the bank
        new_test_account = Account(
            10032021,
            "Jacob",
            "Levenfeld",
            "018071118",
            "0810"
        )
        self.assertFalse(
            test_bank.remove_account_from_bank(new_test_account)
        )

    def test_find_account(self):
        """
        Tests the ability to find an account by number.
        """

        # Since we know where each of the four sample accounts is stored
        #   in the test_bank accounts array, we can compare those
        #   account objects to the account objects returned by the
        #   find_account method
        self.assertEqual(
            test_bank.find_account(23456789),
            test_bank.accounts[0]
        )
        self.assertEqual(
            test_bank.find_account(12345678),
            test_bank.accounts[1]
        )
        self.assertEqual(
            test_bank.find_account(60152005),
            test_bank.accounts[2]
        )
        self.assertEqual(
            test_bank.find_account(90271924),
            test_bank.accounts[3]
        )
    
    def test_find_account_fail(self):
        """
        Tests if None is returned when an account does not exist.
        """

        self.assertEqual(test_bank.find_account(88888888), None)
        self.assertEqual(test_bank.find_account(18), None)
        
    
    def test_add_monthly_interest(self):
        """
        Tests the application of monthly interest to all accounts.
        """

        # Apply the interest to each account
        # 3.75% APR = 0.3125% monthly; multiply by 1.003125
        test_bank.add_monthly_interest(3.75)

        # Check the balances
        self.assertEqual(test_bank.accounts[0].balance, 199324)
        self.assertEqual(test_bank.accounts[1].balance, 16852500000)
        self.assertEqual(test_bank.accounts[2].balance, 6821250000)
        self.assertEqual(test_bank.accounts[3].balance, 36313125000)

        with self.assertRaises(TypeError):
            test_bank.add_monthly_interest("one million")
        with self.assertRaises(ValueError):
            test_bank.add_monthly_interest(-5)
        

        
class TestAccount(unittest.TestCase):
    """
    Tests the following Account class methods:
        deposit
        withdraw
        is_valid_pin
    """
    
    def setUp(self):
        """Sets up the bank with sample accounts."""
        set_up_bank_for_testing(test_bank)
    
    def tearDown(self):
        """Clear selfple accounts from the bank."""
        empty_test_bank(test_bank)
    
    def test_deposit(self):
        """Tests the deposit method using sample accounts."""
        # Deposit amounts into test accounts
        test_bank.accounts[2].deposit(10387.99)
        test_bank.accounts[3].deposit(876543.219)

        # Check that new balances match the math
        self.assertEqual(test_bank.accounts[2].get_balance(), 6801038799)
        self.assertEqual(test_bank.accounts[3].get_balance(), 36287654322)

    def test_withdraw(self):
        """Tests the withdraw method using sample accounts."""
        # Withdraw amounts from test accounts
        test_bank.accounts[1].withdraw(1000000.00)
        test_bank.accounts[2].withdraw(5120.02)

        # Check that new balances match the math
        self.assertEqual(test_bank.accounts[1].get_balance(), 16700000000)
        self.assertEqual(test_bank.accounts[2].get_balance(), 6799487998)

        # Check that error is raised if withdrawal amount exceeds balance
        with self.assertRaises(Exception):
            test_bank.accounts[0].withdraw(2000.00)

    def test_is_valid_pin(self):
        """Tests PIN validation."""
        self.assertTrue(test_bank.accounts[0].is_valid_pin("5678"))
        self.assertTrue(test_bank.accounts[1].is_valid_pin("1234"))
        self.assertFalse(test_bank.accounts[2].is_valid_pin("0990"))
        self.assertFalse(test_bank.accounts[2].is_valid_pin("4981"))


class TestATMachine(unittest.TestCase):
    """
    Tests the following ATMachine class method:
        atm_withdrawal
    """
    
    def setUp(self):
        """Sets up the bank with sample accounts."""

        set_up_bank_for_testing(test_bank)
    
    @classmethod
    def tearDown(self):
        """Clears the sample accounts from the bank."""

        empty_test_bank(test_bank)
    
    def test_atm_withdrawal_bills(self):
        """Tests that the ATM provides the right number of each demoniation"""
        self.assertEqual(ATMachine.atm_withdrawal(145), (7,0,1))
        self.assertEqual(ATMachine.atm_withdrawal(0), (0,0,0))
        self.assertEqual(ATMachine.atm_withdrawal(10), (0,1,0))
        self.assertEqual(ATMachine.atm_withdrawal(95), (4,1,1))
        self.assertEqual(ATMachine.atm_withdrawal(160), (8,0,0))

        # Each of these hypothetical withdrawal amounts should result in an
        #   error (not multiple of 5, negative, too big)
        with self.assertRaises(ValueError):
            ATMachine.atm_withdrawal(33)
        with self.assertRaises(ValueError):
            ATMachine.atm_withdrawal(-5)
        with self.assertRaises(ValueError):
            ATMachine.atm_withdrawal(1010)
    
    def test_atm_withdrawal_withdrawal(self):
        """
        Tests that the ATM withdrawal total is correctly withdrawn from an
        account if an account number for withdrawal is provided.
        """

        self.assertEqual(
            ATMachine.atm_withdrawal(550, test_bank.accounts[1]),
            (27, 1, 0, 16799945000),
        )
        self.assertEqual(
            ATMachine.atm_withdrawal(750, test_bank.accounts[2]),
            (37, 1, 0, 6799925000),
        )
        self.assertEqual(
            ATMachine.atm_withdrawal(955, test_bank.accounts[3]),
            (47, 1, 1, 36199904500),
        )

        # The ATM should raise an error if the withdrawal amount exceeds
        #   the account balance:
        with self.assertRaises(Exception):
            ATMachine.atm_withdrawal(1000, test_bank.accounts[0])
            # The second call should raise the exception (overdrawn)
            ATMachine.atm_withdrawal(1000, test_bank.accounts[0])
        
        
class TestCoinCollector(unittest.TestCase):
    """
    Tests the following CoinCollector class method:
        parse_change
    """

    
    def setUp(self):
        """Sets up the bank with sample accounts."""

        set_up_bank_for_testing(test_bank)
    
    def tearDown(self):
        """Clears the sample accounts from the bank."""

        empty_test_bank(test_bank)
    
    def test_parse_change_totalCoins(self):
        """Tests that the total number of coins processed is accurate"""

        self.assertEqual(CoinCollector.parse_change("QHDPPNDW")[0], 8)
        self.assertEqual(CoinCollector.parse_change("qhdppndw")[0], 8)
        self.assertEqual(CoinCollector.parse_change("qhDpPndW")[0], 8)
        self.assertEqual(CoinCollector.parse_change("P N D Q H W ")[0], 6)
        self.assertEqual(CoinCollector.parse_change("DFYWQQNQQPNPW")[0], 13)
        self.assertEqual(CoinCollector.parse_change("0123456789")[0], 10)
        self.assertEqual(CoinCollector.parse_change("")[0], 0)
    
    def test_parseChange_changeTotal(self):
        """Tests that the total value of valid coins is accurate"""

        self.assertEqual(CoinCollector.parse_change("QHDPPNDW")[1], 202)
        self.assertEqual(CoinCollector.parse_change("qhdppndw")[1], 202)
        self.assertEqual(CoinCollector.parse_change("qhDpPndW")[1], 202)
        self.assertEqual(CoinCollector.parse_change("P N D Q H W ")[1], 191)
        self.assertEqual(CoinCollector.parse_change("DFYWQQNQQPNPW")[1], 322)
        self.assertEqual(CoinCollector.parse_change("0123456789")[1], 0)
        self.assertEqual(CoinCollector.parse_change("")[1], 0)
    
    def test_parseChange_badCoins(self):
        """Tests that the number of rejected coins is counted correctly"""

        self.assertEqual(CoinCollector.parse_change("QHDPPNDW")[2], 0)
        self.assertEqual(CoinCollector.parse_change("qhdppndw")[2], 0)
        self.assertEqual(CoinCollector.parse_change("qhDpPndW")[2], 0)
        self.assertEqual(CoinCollector.parse_change("P N D Q H W ")[2], 0)
        self.assertEqual(CoinCollector.parse_change("DFYWQQNQQPNPW")[2], 2)
        self.assertEqual(CoinCollector.parse_change("0123456789")[2], 10)
        self.assertEqual(CoinCollector.parse_change("")[2], 0)
    
    def test_parseChange_badCoinsList(self):
        """Tests that the rejected coins are listed correctly"""

        self.assertEqual(CoinCollector.parse_change("QHDPPNDW")[3], "")
        self.assertEqual(CoinCollector.parse_change("qhdppndw")[3], "")
        self.assertEqual(CoinCollector.parse_change("qhDpPndW")[3], "")
        self.assertEqual(CoinCollector.parse_change("P N D Q H W ")[3], "")
        self.assertEqual(CoinCollector.parse_change("DFYWQQNQQPNPW")[3], "FY")
        self.assertEqual(CoinCollector.parse_change("0123456789")[3], "0123456789")
        self.assertEqual(CoinCollector.parse_change("")[3], "")
    
    def test_parseChange_deposit(self):
        """
        Tests that the change total is correctly deposited to an account
        if an account number for deposit is provided.
        """

        CoinCollector.parse_change("QQQQPPP", test_bank.accounts[0])
        self.assertEqual(test_bank.accounts[0].get_balance(), 198806)


class TestBankUtility(unittest.TestCase):
    """
    Tests the following BankUtility class methods:
        convert_dollars_to_cents
        convert_cents_to_dollars
        is_numeric
        generate_pin
        generate_account_number
    """

    def test_convert_dollars_to_cents(self):
        """
        Tests that dollar amounts are correctly converted to cents.
        """
        
        self.assertEqual(BankUtility.convert_dollars_to_cents(1.50), 150)
        self.assertEqual(BankUtility.convert_dollars_to_cents(1000000), 100000000)
        with self.assertRaises(TypeError):
            BankUtility.convert_dollars_to_cents("Hello, World!")
    
    def test_convert_cents_to_dollars(self):
        """
        Tests that cents  are correctly converted to dollars.
        """

        self.assertEqual(BankUtility.convert_cents_to_dollars(900), 9.0)
        self.assertEqual(BankUtility.convert_cents_to_dollars(43770), 437.7)
        with self.assertRaises(TypeError):
            BankUtility.convert_cents_to_dollars("Goodbye, World!")
    
    def test_is_numeric(self):
        """
        Tests that strings containining only digits are correctly identified.
        """
        
        self.assertTrue(BankUtility.is_numeric("12345"))
        self.assertTrue(BankUtility.is_numeric("67890"))
        self.assertFalse(BankUtility.is_numeric("1.0"))
        self.assertFalse(BankUtility.is_numeric("digit"))
        self.assertFalse(BankUtility.is_numeric("10 "))
        self.assertFalse(BankUtility.is_numeric("142,857"))
        self.assertFalse(BankUtility.is_numeric("-17"))
    
    def test_generate_pin(self):
        """
        Generates a bunch of PINs and checks that each is valid
        """
        
        for i in range(100000):
            test_pin = BankUtility.generate_pin(4)
            self.assertEqual(len(test_pin), 4)
            self.assertTrue(BankUtility.is_numeric(test_pin))
    
    def test_generate_account_number(self):
        """
        Generates a bunch of account numbers and checks that each is valid
        """
        
        for i in range(100000):
            test_acctnum = BankUtility.generate_account_number(8)
            self.assertEqual(math.floor(math.log10(test_acctnum)+1), 8)

if __name__ == '__main__':
    unittest.main(buffer=True, verbosity=2)